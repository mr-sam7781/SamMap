from colorama import Fore, init
import pyfiglet

init(autoreset=True)

def show_banner():

    colors = [
        Fore.RED,
        Fore.YELLOW,
        Fore.GREEN,
        Fore.CYAN,
        Fore.BLUE,
        Fore.MAGENTA
    ]

    banner = pyfiglet.figlet_format("SamMap")

    for i, line in enumerate(banner.split("\n")):
        print(colors[i % len(colors)] + line)

    print(Fore.GREEN + "Network Recon Scanner")
    print(Fore.MAGENTA + "By MR.SAM\n")
