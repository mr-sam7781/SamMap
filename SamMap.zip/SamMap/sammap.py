from banner import show_banner
import nmap
import time

show_banner()

target = input("Enter Target IP : ")

scanner = nmap.PortScanner()

print("\n[+] Scanning Please Wait...\n")

start_time = time.time()

scanner.scan(target, arguments="-sV")

end_time = time.time()

open_ports = 0

for host in scanner.all_hosts():

    print(f"\nHost : {host}")

    print("-" * 90)
    print(f"{'PORT':<10}{'STATE':<10}{'SERVICE':<20}{'VERSION'}")
    print("-" * 90)

    for proto in scanner[host].all_protocols():

        ports = sorted(scanner[host][proto].keys())

        for port in ports:

            state = scanner[host][proto][port]['state']
            service = scanner[host][proto][port]['name']

            product = scanner[host][proto][port].get('product', '')
            version = scanner[host][proto][port].get('version', '')
            extrainfo = scanner[host][proto][port].get('extrainfo', '')

            full_version = f"{product} {version} {extrainfo}".strip()

            print(
                f"{str(port):<10}"
                f"{state:<10}"
                f"{service:<20}"
                f"{full_version}"
            )

            if state == "open":
                open_ports += 1

print("\n" + "=" * 90)
print(f"[+] Total Open Ports : {open_ports}")
print(f"[+] Scan Time : {round(end_time - start_time, 2)} seconds")

# Report Save
with open("reports/report.txt", "w") as report:

    report.write(f"Target : {target}\n")
    report.write(f"Open Ports : {open_ports}\n")
    report.write(f"Scan Time : {round(end_time - start_time, 2)} seconds\n")

print("[+] Report Saved : reports/report.txt")
